A Pen created at CodePen.io. You can find this one at https://codepen.io/teeganlincoln/pen/MaNxBv.

 A gallery that reveals three panels as the user scrolls.